# coding=utf-8

#On cherche à savoir le volume d'eau entre des bars en
#sachant leur hauteur en gardant la complexité en O(n)



#L'idée est de divisée les bars en blocs qui peuvent contenir de l'eau
#Ainsi en ajoutant le volume d'eau contenu dans chaque bloc on obtient le volume d'eau total
#Un bloc va de l'indice de début jusqu'à l'indice de la bar qui est plus haute que la bar initiale

import time
import random

import water

#Cette fonction détermine le bloc à l'indice donnée calcule et retournele volume en
#son sein ainsi que l'indice du prochain bloc

def Volume_Bloc(indice,list):  
    a=indice
    b=indice+1     
    volume=0
    for i in range (indice+1,len(list),1):
        if list[i]>=list[a]:
            b=i
            break
        elif list[i]>list[i-1] and list[i]>list[b]:
            b=i
    if list[b]>=list[a]:        #si la dernière bar du bloc est la plus grande
        for i in range(a,b,1):
            volume+=list[a]-list[i]
        return volume,b
    elif b==a:               #volume si le bloc est juste la bar en elle-même
        return volume,b
    else:                    #volume si la première bar du bloc est la plus grande
        for i in range(a,b,1):
            if list[b]-list[i]>0:
                volume+=list[b]-list[i]
        return volume,b

#calcule le volume total en faisant la somme des volumes bloc
def Volume_total(list):
    i=0
    volume_tot=0
    while i<len(list)-1:       
        volume_tot+=Volume_Bloc(i,list)[0]
        i=Volume_Bloc(i,list)[1]
    return volume_tot

#calcul temps et vérification que la complexité est linéaire


b = 10
for test in range(5):
    # test_taille1=[random.randint(0,b) for i in range(b)]
    test_taille1=range(b,-1,-1)

    tps1=time.time()
    resultat_1= Volume_total(test_taille1)
    tps2=time.time()
    tps3=tps2-tps1
    print("volume de",resultat_1,"temps de:",tps3,"pour taille de:",b)

    tps1=time.time()
    resultat_2=water.volume(test_taille1)
    tps2=time.time()
    tps4=tps2-tps1
    print("volume de",resultat_2,"temps de:",tps4,"pour taille de:",b)

    print("rapport de temps de:",tps4/tps3,"pour un rapport de taille de liste de:",int(b)/int(b))
    
    if resultat_1 != resultat_2 :
        break
        
    b *= 10
    
    
    
    
