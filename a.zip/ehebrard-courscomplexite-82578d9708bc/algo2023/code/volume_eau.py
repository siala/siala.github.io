# coding=utf-8

#On cherche à savoir le volume d'eau entre des bars en
#sachant leur hauteur en gardant la complexité en O(n)



#L'idée est de divisée les bars en blocs qui peuvent contenir de l'eau
#Ainsi en ajoutant le volume d'eau contenu dans chaque bloc on obtient le volume d'eau total
#Un bloc va de l'indice de début jusqu'à l'indice de la bar qui est plus haute que la bar initiale

import time
import random
import water

#Cette fonction détermine le bloc à l'indice donnée calcule et retournele volume en
#son sein ainsi que l'indice du prochain bloc

def Volume_Bloc(indice,list):  
    a=indice
    b=indice+1     
    volume=0
    print 's', indice+1, 
    for i in range (indice+1,len(list),1):
        print i,
        if list[i]>=list[a]:
            b=i
            print '->', b
            break
        elif list[i]>list[i-1] and list[i]>list[b]:
            b=i
    print '->', b
    if list[b]>=list[a]:        #si la dernière bar du bloc est la plus grande
        for i in range(a,b,1):
            volume+=list[a]-list[i]
        return volume,b
    elif b==a:               #volume si le bloc est juste la bar en elle-même
        print 'here'
        return volume,b+1
    else:                    #volume si la première bar du bloc est la plus grande
        for i in range(a,b,1):
            if list[b]-list[i]>0:
                volume+=list[b]-list[i]
            return volume,b+1

#calcule le volume total en faisant la somme des volumes bloc
def Volume_total(list):
    i=0
    volume_tot=0
    while i<len(list)-1:
        
        v,b = Volume_Bloc(i,list)
        
        print 'bloc [%i,%i]:%i'%(i, b, v)
        
        volume_tot+=v
        i=b
    return volume_tot

#calcul temps et vérification que la complexité est linéaire
# b=input("Taille de la premiere liste  ")
# c=input("Taille de la seconde liste  ")

# test_taille1=[random.randint(0,10) for i in range(1000)]
test_taille1=[2,1,4,1,6,1,8,1,9,1,7,5,1,3]
# test_taille1=range(5,0,-1)
# test_taille1.extend(range(2,5))
# test_taille1.extend(range(3,0,-1))
# test_taille1.extend(range(2,6))

# test_taille2=[random.randint(0,10) for i in range(int(c))]

print ' '.join([str(x) for x in test_taille1])

tps1=time.time()
resultat_1=Volume_total(test_taille1)
tps2=time.time()
tps3=tps2-tps1
print("volume de",resultat_1,"temps de:",tps3)

tps1=time.time()
resultat_2=water.volume(test_taille1)
tps2=time.time()
tps4=tps2-tps1
print("volume de",resultat_2,"temps de:",tps4)

# print("rapport de temps de:",tps4/tps3,"pour un rapport de taille de liste de:",int(c)/int(b))



