
from utils import *


def greedy_distance(points, k):
    
    partition = [[] for i in range(k)]
    
    x,y = max(pair_of(points), key=lambda (x,y) : distance(x,y))
    
    partition[0].append(x)
    partition[1].append(y)
    
    done = set([x,y])
    
    for i in range(2,k):
        z = max(points, key=lambda a : min([distance(a,L[0]) for L in partition[:i]]))
        partition[i].append(z)
        done.add(z)
        
    for x in points:
        if not x in done:
            i = arg_min([max_distance(x,L) for L in partition])
            partition[i].append(x)

    
    return partition
