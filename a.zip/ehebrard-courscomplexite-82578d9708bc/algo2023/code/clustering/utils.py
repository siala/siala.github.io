import math
import numpy as np

def pair_of(l):
    pairs = []
    for j in range(1,len(l)):
        for i in range(j):
            pairs.append((l[i],l[j]))
    return pairs

def distance(x,y):
    x1,y1 = x
    x2,y2 = y
    return math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2))
    
def max_distance(x,L):
    if len(L) == 0:
        return 0
    x1,y1 = x
    return max([distance(x,y) for y in L])
    
def diameter(L):
    return max([max_distance(x,L) for x in L])
    
def arg_max(L):
    return np.argmax(L)
    
def arg_min(L):
    return np.argmin(L)


def score(P):
    return max([diameter(L) for L in P])



