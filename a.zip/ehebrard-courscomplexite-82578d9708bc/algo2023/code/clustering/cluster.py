
import matplotlib.pyplot as plt
import random
import glouton

from utils import *


colors = ['r','b','g','y','o']
random.seed(12345)
M = 1000
K= 5
N = 50
infinity = float("inf")



def generate_seeds(k):
    return [(random.randint(0,M), random.randint(0,M)) for i in range(k)]
    
def generate_points(n, seeds, d):
    points = []
    for i in range(n):
        x,y = seeds[random.randint(0,len(seeds)-1)]
        points.append((x+random.randint(0,d)-d/2, y+random.randint(0,d)-d/2))
    return points

def add(partition, ax):
    for points,c in zip(partition,colors):
        ax.scatter([p[0] for p in points], [p[1] for p in points], color=c)





if __name__ == '__main__':
    
    seeds = generate_seeds(K)

    points = generate_points(N, seeds, M/3)
        
    partition = glouton.greedy_distance(points,2)
    print score(partition)




    fig=plt.figure()
    ax=fig.add_axes([0,0,1,1])

    add(partition, ax)

    plt.show()






