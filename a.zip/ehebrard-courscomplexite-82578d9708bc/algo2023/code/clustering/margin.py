def greedy_margin(points, k):
    
    partition = [[] for i in range(k)]
    A = {}
    pairs = reversed(sorted(pair_of(points), key=lambda (x,y) : distance(x,y)))

    for x,y in pairs:
        dx = [(A[x], max_distance(x, A[x]))] if A.has_key(x) else [(L, max_distance(x,L)) for L in partition]
        dy = [(A[y], max_distance(y, A[y]))] if A.has_key(y) else [(L, max_distance(y,L)) for L in partition]
        dxy = distance(x,y)
        
        
        best = (None,None)
        best_margin = infinity
        for Li,mx in dx:
            for Lj,my in dy:
                margin = max(mx, my)
                if Li is Lj:
                    margin = max(margin, dxy)
                if margin < best_margin:
                    best = Li,Lj
                    best_margin = margin 
        
        Li,Lj = best
        
        Li.append(x)
        A[x] = Li        
        Lj.append(y)
        A[y] = Lj


    return partition
