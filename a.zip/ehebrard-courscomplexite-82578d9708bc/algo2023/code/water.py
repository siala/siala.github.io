

# compute the successive maximums
def maxes(L):
    m = 0
    ms = []
    for b in L:
        m = max(m,b)
        ms.append(m)
    return ms
    
    
def volume(histo):
    v = 0    
    right_max = maxes(reversed(histo))
    right_max.reverse()
    l = histo[0]
    for b,r in zip(histo, right_max):
        l = max(l, b)
        v += max(0, min(r,l)-b)
    return v
        
 
