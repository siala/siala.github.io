



L = range(11)


mil = len(L) // 2

print L[:mil], L[mil], L[mil+1:]

