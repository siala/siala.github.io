
def factorial(x):
    f = 1
    for i in range(2,x+1):
        f *= i
    return f


def hour(x):
    return x/3600
    
def day(x):
    return hour(x)/24
    
def year(x):
    return day(x)/365
    
def age_of_the_universe(x):
    return year(x)/13000000000


planck_time = 5.39 * (10 ** -44) # seconds

planck_length = 1.616 * (10 ** -35) # meters

volume_universe = 8.9 * (10 ** 79) # meters^3

num_procs = volume_universe / (planck_length ** 3)


fast_computer = 1/3330000000.0


# for n in range(50):
#     print 'n=%-2i: %10f ages %10f years %10f days %10f hours %10f seconds'%(n, age_of_the_universe(fast_computer*factorial(n)), year(fast_computer*factorial(n)), day(fast_computer*factorial(n)), hour(fast_computer*factorial(n)), fast_computer*factorial(n))
#
#
#
# for n in range(50):
#     print 'n=%-2i: %10f ages %10f years %10f days %10f hours %10f seconds'%(n, age_of_the_universe(planck_time*factorial(n)), year(planck_time*factorial(n)), day(planck_time*factorial(n)), hour(planck_time*factorial(n)), planck_time*factorial(n))


print planck_time, num_procs

for n in range(100,150):
    num_instructions = factorial(n)
    
    time = num_instructions * planck_time / num_procs
    
    print 'n=%-2i: %10f ages %10f years %10f days %10f hours %10f seconds'%(n, \
    age_of_the_universe(time), year(time), \
    day(time), hour(time), time)





