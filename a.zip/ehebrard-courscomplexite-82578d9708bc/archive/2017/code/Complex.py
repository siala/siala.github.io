import random
import time
import sys


def AppartientLineaire(x,L):
    for l in L:
        if x == l:
            return True
    return False
    
def AppartientDichotomie(x,L):
    p = int(len(L)/2)
    if len(L) == 0:
        return False
    if L[p] == x:
        return True
    if L[p] > x:
        return AppartientDichotomie(x, L[:p])
    return AppartientDichotomie(x, L[p+1:])
    


def evaluate(algos,N,R,s=1234):    
    results = {}.fromkeys(algos)
    cputime = {}.fromkeys(algos)
    
    for algo in algos:
        results[algo] = []
        cputime[algo] = []
        random.seed(s)
        for i in range(R):
            L = [random.randint(0,5)]
            for i in range(N):
                L.append(L[-1]+random.randint(0,5))
            x = random.randint(0,N*5)
            
            start = time.time()
            results[algo].append(algo(x,L))
            cputime[algo].append(time.time()-start)
            
    for i in range(R):
        for x in range(len(algos)-1):
            for y in range(x, len(algos)):
                if results[algos[x]][i] != results[algos[y]][i]:
                    print 'resultat incoherent!!'
                    print results[algos[x]]
                    print results[algos[y]]
                    sys.exit(1)
                    
    return [float(sum(cputime[a]))/float(R) for a in algos]
        
        



if __name__ == '__main__':
    for S in range(1000,100001,1000):
        t = evaluate([AppartientLineaire,AppartientDichotomie], S, 10)
        print '%-10i  %10.5f %10.5f'%(S, t[0], t[1]) 
    
    
    

        
        
