
def Appartient(x,L):
    p = int(len(L)/2)
    if len(L) == 0:
        return False
    if L[p] == x:
        return True
    if L[p] > x:
        return Appartient(x, L[:p])
    return Appartient(x, L[p+1:])
