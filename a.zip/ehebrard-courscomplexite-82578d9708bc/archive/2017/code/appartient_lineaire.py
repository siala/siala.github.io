
def Appartient(x,L):
    for l in L:
        if x == l:
            return True
    return False
    